id = environment.ItemData()
id.itemID = "keyring"
id.itemName = "Brass Keys"
id.customFlavor = "Beneath the body of a goblin lies "
id.isPickup = True
env.dungeonitems['keyring'] = id