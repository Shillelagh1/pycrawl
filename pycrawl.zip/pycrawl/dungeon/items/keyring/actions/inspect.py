print("It's a key ring devoid of detail save for two identical worn brass skeleton keys.")
print(" ")