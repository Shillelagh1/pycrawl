if env.room == "start":
    print("You insert the keys into the impression on the wall and slowly turn it.\nImmediately a door springs into motion, revealing a hidden passage!\nThe key is jammed into the receptacle.")
    env.roomd.variables["dooropen"] = True
    env.roomd.addRelativeMove("south", "cache")
    for i in env.playeritems:  # Key jammed
        if i.itemID == "keyring":
            env.playeritems.remove(i)
else:
    print("You aren't sure what to do with these here.")

print(" ")
ScriptOnAll("passtime.py", env)