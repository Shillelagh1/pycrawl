id = environment.ItemData()
id.itemID = "dagger"
id.itemName = "Rusted Dagger"
id.customFlavor = "In the corner lies a "
id.isPickup = True
env.dungeonitems['rdagger'] = id