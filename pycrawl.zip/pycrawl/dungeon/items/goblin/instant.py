import sys
import time


def monster_attack(env):
    dmg = random.randint(1,4)
    print("The goblin strikes you for " + str(dmg) + " hit points!")
    env.variables["hp"] = env.variables["hp"] - dmg
    print("You have " + str(env.variables["hp"]) + " hit points left.")

health = 15

print("An Enraged Goblin confronts you!")
time.sleep(3)
if env.dungeonitems["rdagger"] in env.playeritems:
    while env.variables["hp"] > 0 and health > 0:
        print("You have a dagger to fight it with!")
        monster_attack(env)
        dmg = random.randint(2,7)
        health = health - dmg
        print("You strike the goblin for " + str(dmg) + " hit points. It has " + str(health) + " left.")
        time.sleep(1)

    if env.variables["hp"] < 1 and health < 1:
        print("You both died. Such a shame.")
        input()
        sys.exit()
    if env.variables["hp"] < 1:
        print("You died!")
        input()
        sys.exit()
    if health < 1:
        print("You killed the beast!")
        print("The goblin drops a ring of shiny brass keys onto the floor.")
        env.roomd.items.remove(env.dungeonitems["goblin"])
        env.roomd.items.append(env.dungeonitems["keyring"])
else:
    tries = 0
    running = True
    print("You don't have a weapon, so you will have to run.")
    while running:
        print("Input a number:")
        num = input()
        try:
            if (int(num) + tries) & 1 << 2 > 0:
                print("You escaped! You run back out to the hallway.")
                running = False
                env.SetRoom("hallway")
            else:
                print("You didn't make it out!")
                monster_attack(env)
                tries += 1

            if env.variables["hp"] < 1:
                print("You died!")
        except:
            print("That's not a number!")