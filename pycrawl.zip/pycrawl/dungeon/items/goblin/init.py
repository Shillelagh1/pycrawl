id = environment.ItemData()
id.itemID = "goblin"
id.itemName = "Enraged Goblin"
id.customFlavor = None
id.isPickup = False
env.dungeonitems['goblin'] = id