id = environment.ItemData()
id.itemID = "leaflet"
id.itemName = "Bloodied Leaflet"
id.customFlavor = "Below the body of a slain adventurer lies a "
id.isPickup = True
env.dungeonitems['leaflet'] = id