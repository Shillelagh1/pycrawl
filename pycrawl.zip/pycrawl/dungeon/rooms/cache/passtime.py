if env.room == "cache":
    print("A great clock on the wall ticks away")
else:
    print("You hear a distant ticking")