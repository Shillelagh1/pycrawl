nr = environment.RoomData()
nr.name = "Secret Cache"
nr.path = "dungeon/rooms/cache"
nr.addRelativeMove("north", "start")
nr.items.append(env.dungeonitems["leaflet"])
env.dungeonrooms['cache'] = nr
