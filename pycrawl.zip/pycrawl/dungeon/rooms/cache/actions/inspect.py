print("You find yourself in a damp hidden room!\nA tight hidden passage to the North leads to an expansive cavern.")
print(" ")