nr = environment.RoomData()
nr.name = "Dim Vault"
nr.path = "dungeon/rooms/vault"
nr.addRelativeMove("south", "hallway")
nr.items.append(env.dungeonitems["goblin"])
env.dungeonrooms['vault'] = nr
