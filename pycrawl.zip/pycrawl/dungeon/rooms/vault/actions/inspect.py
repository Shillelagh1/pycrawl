print("You find yourself in a dimly lit cave vault. To the South is a hallway.")
print(" ")