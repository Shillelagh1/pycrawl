nr = environment.RoomData()
nr.name = "Caverns"
nr.path = "dungeon/rooms/start"
nr.variables['dooropen'] = False
nr.addRelativeMove("west", "hallway")
env.dungeonrooms['start'] = nr