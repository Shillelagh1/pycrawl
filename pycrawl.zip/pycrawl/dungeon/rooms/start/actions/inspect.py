print("You find yourself in a nondescript stone cavern.\nA doorway adorned with golden lacing leads into a walkway to the West.")
if env.dungeonrooms['start'].variables['dooropen']:
	print("There is a tight hidden passage in the South wall.")
else:
	print("There is a keyhole impression on the South wall.")

print(" ")