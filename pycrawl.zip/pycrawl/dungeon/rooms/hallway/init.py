nr = environment.RoomData()
nr.name = "Stone Hallway"
nr.path = "dungeon/rooms/hallway"
nr.addRelativeMove("east", "start")
nr.addRelativeMove("north", "vault")
nr.items.append(env.dungeonitems["rdagger"])
env.dungeonrooms['hallway'] = nr
