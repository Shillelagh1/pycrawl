print("You find yourself in a elegant stone walkway.\nA cavity to the East leads to an expansive cavern.\nA passage to the North leads into a dim cave vault.")
print(" ")