if len(env.playeritems) > 0:
    if len(args) > 1:
        somethingtodrop = not args[1] == ''
    else:
        somethingtodrop = False

    if not somethingtodrop:
        print("Drop what? I have:")

    dropped = False
    for i in env.playeritems:
        if somethingtodrop:

            if args[1].strip(' .').lower() == i.itemName.lower():
                print("Dropping the " + i.itemName + ".")
                env.roomd.items.append(i)
                env.playeritems.remove(i)
                i.customFlavor = None
                dropped = True

        else:
            print("~" + i.itemName)

    if not dropped:
        print("I don't have a \"" + args[1] + "\"")
    else:
        if len(env.playeritems) > 0:
            print("I now have:")
            for i in env.playeritems:
                print("~" + i.itemName)
        else:
            print("I now have nothing.")

else:
    print("I have nothing to drop.")

print(" ")