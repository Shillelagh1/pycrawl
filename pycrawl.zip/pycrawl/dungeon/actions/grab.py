grabbableitems = 0
for i in env.roomd.items:
    if i.isPickup:
        grabbableitems += 1

if grabbableitems > 0:
    if len(args) > 1:
        somethingtograb = not args[1] == ''
    else:
        somethingtograb = False

    if not somethingtograb:
        print("Grab what? There is:")
    grabbed = False
    for i in env.roomd.items:
        if somethingtograb:
            if args[1].strip(' .').lower() == i.itemName.lower():
                if i.isPickup:
                    print("Picking up the " + i.itemName)
                    env.playeritems.append(i)
                    env.roomd.items.remove(i)
                    grabbed = True
        else:
            if i.isPickup:
                print("~" + i.itemName)

    if not grabbed:
        if i.isPickup:
            print("I can't find \"" + args[1] + "\" here")
    else:
        print("I now have:")
        for i in env.playeritems:
            print("~" + i.itemName)

else:
    print("There is nothing here to grab.")

print(" ")