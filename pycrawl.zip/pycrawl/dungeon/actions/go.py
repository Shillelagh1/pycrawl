uin = args[1].lower()
if uin in env.roomd.relative_moves.keys():
	destination = env.roomd.relative_moves[uin]
	env.SetRoom(destination)

	ScriptOnAll("passtime.py", env)
else:
	print('I don\'t know where "' + uin + '" is')
