TryExecFileInRoomByName("actions/inspect.py", env.room, env)
for i in env.roomd.items:
    print((i.customFlavor and i.customFlavor or "There is a ") + i.itemName)
