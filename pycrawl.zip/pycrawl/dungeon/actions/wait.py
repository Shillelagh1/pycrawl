print("You wait for a couple moments...")

ScriptOnAll("passtime.py", env)