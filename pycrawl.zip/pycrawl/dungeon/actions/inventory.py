if len(env.playeritems) > 0:
    print("You are holding:")
    for i in env.playeritems:
        print("~" + i.itemName)
else:
    print("You don't have anything yet.")