import pcs
from os.path import exists
import environment
from glob import glob
import time
import random

# Pymips by Shillelagh 2023


def execFile(filename, env, args=""):
    try:
        exec(open(filename).read())
    except Exception as e:
        f = open("log.txt", 'a')
        f.write(str(e))
        f.write("\n")

    # pmips execute
    #file = open(filename)
    #content = ""
    #for i in file:
    #    content += i
    #execScript(content, env)


def cleanupScript(lines):
    tlines = []
    for i in lines:
        txt = i
        if txt.startswith('\n'):
            txt = txt[1:]
        inquotes = False
        nstr = ""
        for c in txt:
            if c == '"':
                inquotes = not inquotes
            if not inquotes:
                if not c == ' ':
                    nstr += c
            else:
                nstr += c
        if not nstr == '':
            tlines.append(nstr)

    return tlines


def execScript(file, env):
    lines = cleanupScript(file.split(';'))
    i = 0
    while i < len(lines):
        line = lines[i]
        parts = line.split('|')
        if hasattr(pcs, parts[0].lower()):
            execute = getattr(pcs, parts[0].lower())
            o = execute(parts, env, lines)
            if o:
                i = o
        i += 1


def execPython(filename, env, args=""):
    if exists(filename):
        file = open(filename)
        lines = file.readlines()
        contents = ""
        for i in lines:
            contents += i
        if len(contents) > 0:
            eval(contents)


# Begin PyCRawl specific code


def TryExecFileInRoomByName(scriptPath, rp, env, type="rooms"):
    if exists("dungeon/" + type + "/" + rp + "/" + scriptPath):
        execFile("dungeon/" + type + "/" + rp + "/" + scriptPath, env)


def TryExecFileInRoom(scriptPath, rp, env):
    if exists(rp + "/" + scriptPath):
        execFile(rp + "/" + scriptPath, env)

def ScriptOnAll(scriptPath, env, type="rooms"):
    roomfolders = glob("dungeon/" + type + "/*/")
    for directory in roomfolders:
        TryExecFileInRoom(scriptPath, directory, env)
