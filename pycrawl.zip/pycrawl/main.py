import environment
import scriptrunner as sr
from os.path import exists
from glob import glob





env = environment.Environment()
sr.ScriptOnAll("init.py", env, "items")
sr.ScriptOnAll("init.py", env)
sr.execFile("dungeon/init.py", env)
env.FindStart()
env.EnterRoom()

while True:
    inStr = input().strip('. ')
    args = inStr.split(' ', 1)
    ran = False
    itempath = None
    if len(args) > 1:
        for i in env.playeritems:
            if i.itemName.lower() == args[1].lower():
                if exists("dungeon/items/" + i.itemID + "/actions/" + args[0] + ".py"):
                    itempath = i.itemID
    if itempath:
        sr.TryExecFileInRoomByName("actions/" + args[0] + ".py", itempath, env, "items")
    elif exists("dungeon/actions/" + args[0] + ".py"):
        ran = sr.execFile("dungeon/actions/" + args[0] + ".py", env, args)
    elif exists("dungeon/rooms/" + env.room + "/actions/" + args[0] + ".py"):
        ran = sr.TryExecFileInRoomByName("actions/" + args[0] + ".py", env.room, env)
    else:
        print("I've no clue how to \"" + args[0] + "\".")

