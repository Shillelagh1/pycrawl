import environment
import scriptrunner as sr
from os.path import exists

showignorechars = ['"', '$']

# Utility commands

def replaceInString(string, index):
    return string[:index - 1] + '"' + string[index:]


def toLabel(args, lines):
    for i in range(len(lines)):
        line = lines[i]
        if line == args[1]:
            return i

# Script commands

# Show text or variable to player
def show(args, env, lines):
    args.pop(0)
    for line in args:
        toprint = ""
        nl = line
        for i in range(len(line)):
            c = line[i]
            if not c in showignorechars:
                if i - 1 > 0:
                    if not line[i - 1] == "$":
                        toprint += c
                    else:
                        vn = ""
                        going = True
                        for t in range(i, len(line)):
                            if going:
                                line = replaceInString(line, t)
                                if line[t] == " ":
                                    going = False
                                else:
                                    vn += line[t]
                        toprint += env.variables[vn]  # Make this safe against nonexistent variables
                else:
                    toprint += c
        fprint = ""
        for i in toprint:
            if not i == '"':
                fprint += i
        print(fprint)


# Execute a file in the current room
# TODO: Log if the file is nonexistent
def exechere(args, env, lines):
    if exists(env.room + "/" + args[1]):
        sr.execFile(env.room + "/" + args[1], env)


def setroom(args, env, lines):
    print("")


def dopython(args, env, lines):
    eval(args[1])


# Flow Commands


def jump(args, env, lines):
    return toLabel(args, lines)


# Data Packer Commands


def beginroomdata(args, env, lines):
    env.progress_data_pack = environment.RoomData()


def dataname(args, env, lines):
    env.progress_data_pack.name = args[1]


def addrelativemove(args, env, lines):
    env.progress_data_pack.addRelativeMove(args[1], args[2])


def roompack(args, env, lines):
    env.dungeonrooms.append(env.progress_data_pack)
