def writeLog(string):
    f = open("log.txt", 'a')
    f.write(string)
    f.write("\n")
    f.close()