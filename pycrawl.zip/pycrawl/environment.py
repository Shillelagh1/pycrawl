import scriptrunner as sr
import util

class Environment:
    room = ""
    roomd = None
    dungeonrooms = {}
    dungeonitems = {}
    playeritems = []
    variables = {}

    def EnterRoom(self):
        sr.TryExecFileInRoomByName("instant.py", self.room, self)
        for k, v in self.dungeonitems.items():
            if v in self.roomd.items:
                sr.TryExecFileInRoomByName("instant.py", k, self, "items")


    def FindStart(self):
        for k, v in self.dungeonrooms.items():
            if k == "start":
                self.room = k
                self.roomd = v


    def SetRoom(self, roomName):
        f = False
        for k, v in self.dungeonrooms.items():
            if k == roomName:
                self.room = k
                self.roomd = v
                f = True
        if f:
            self.EnterRoom()
        else:
            print("You find yourself blocked from passing by an illusory wall.")
            util.writeLog("Player was blocked from moving to the " + roomName)


class RoomData:
    name = "room"
    path = "dungeon/rooms/start"
    def addRelativeMove(self, source, destination):
        self.relative_moves[source] = destination

    def __init__(self):
        self.relative_moves = {}
        self.variables = {}
        self.items = []

class ItemData:
    itemID = "item"
    itemName = "Item"
    customFlavor = None

    def __init__(self):
        self.variables = {}
        self.isPickup = False
