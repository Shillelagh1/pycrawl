This is where all data describing a room is stored.

--instant.pcr: PyCRawl script that is run immediately upon entering the room.
--items: Directory containing all item informations.
--actions: Directory performing actions that may be performed in this room.