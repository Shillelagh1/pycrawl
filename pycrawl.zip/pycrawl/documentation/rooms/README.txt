All rooms stored here.
The dungeon will immediately jump to the room called "start"

--start: Directory containing the first room to be opened.