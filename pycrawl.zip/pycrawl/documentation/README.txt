This is where all dungeon data is stored!

--rooms: Directory storing all rooms in a dungeon.
--actions: Directory containing PyCRawl scripts that can be executed anywhere as actions. Example: go.pcr